### How to use:
- Use VScode to open a code file with indents, 
- type **>aymlAdd** in the text-input-box on the top, 
- it adds vertical lines to show indent levels, 
- it adds lineNo before each line, 
- the changed code will be saved as a txt file in the same folder.