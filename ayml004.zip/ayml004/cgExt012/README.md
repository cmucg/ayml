### Add lineNo and indent-marks:
- Use VScode to open a code file with indents, 
- type **>aymlAdd** in the text-input-box on the top, 
- it adds vertical lines to show indent levels, 
- it adds lineNo before each line. 

### Remove lineNo and indent-marks:
- Type **>aymlBack** in the text-input-box on the top. 