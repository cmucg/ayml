const vscode = require('vscode')
const fs = require('fs')

function indentSize(s1){
  lines = s1.split(/\r?\n/g)
  lineNos = s1.match(/^ *\d+  /gm)
  if(lineNos && lineNos.length>=lines.length*0.8) return 0
  indentDifs = {}
  indent0 = 0
  for(line of lines){
      lineTrim = line.trimLeft()
      if(! lineTrim) continue  
      indent1 = line.length - lineTrim.length
      indentDif = indent1 - indent0
      indent0 = indent1
      if(indentDif<=0) continue
      if(!indentDifs[indentDif]) indentDifs[indentDif] = 1
      else indentDifs[indentDif] += 1
  }
  
  indentList = Object.entries(indentDifs)
  indentList.sort((x,y)=>(y[1]-x[1]))
  return indentList[0][0]
}

function cgAdd(context) {
  const editor1 = vscode.window.activeTextEditor
  if(!editor1) return
  const doc1 = editor1.document
  const txt1 = doc1.getText()
  const N = indentSize(txt1); if(N<=0) return // already have lineNo
  const re1 = eval(`/(?<=^ *?) {${N}}/gm`)
  const indentNew = '|'.padEnd(N,' ') // N<=2 ? '|  ' : '|'.padEnd(N,' ')
  const txt2 = txt1.replaceAll(re1,indentNew) // replace indents 

  let lines2 = txt2.split(/\r?\n/g) // add lineNo for each line
  lineNoLen = (''+(lines2.length)).length
  for(i in lines2) lines2[i] = String(i*1+1).padStart(lineNoLen,' ')+ '  '+ lines2[i]
  const txt3 = lines2.join('\r\n')
  // const filePath2 = doc1.uri.fsPath + '.txt'
  // fs.writeFileSync(filePath2, txt3, 'utf8')
  const cgRange = new vscode.Range(
    vscode.window.activeTextEditor.document.positionAt(0),
    vscode.window.activeTextEditor.document.positionAt(txt1.length)
  )
  vscode.window.activeTextEditor.edit(e=>{e.replace(cgRange,txt3)}).then(success=>{})
  // vscode.window.showInformationMessage(filePath2)
}
// vscode.window.activeTextEditor.document.getText()
function cgBack(context){
  const txt1 = vscode.window.activeTextEditor.document.getText()
  const lineNos = txt1.match(/^ *\d+  /gm); const lineEnds = txt1.match(/\n/gm); if((!lineNos) || lineNos.length<=lineEnds.length*0.5) return
  const re2 = /^ *\d+  /gm  // lineNo
  const re3 = /(?<=^[ \|]*?)\|/gm  // vertical line |
  const txt2 = txt1.replaceAll(re2,'').replaceAll(re3,' ')
  const cgRange = new vscode.Range(
    vscode.window.activeTextEditor.document.positionAt(0),
    vscode.window.activeTextEditor.document.positionAt(txt1.length)
  )
  vscode.window.activeTextEditor.edit(e=>{e.replace(cgRange,txt2)}).then(success=>{})
  // console.log('ok') // BreakPoint for interact
}

function activate(context) {
  let aymlAddCommand = vscode.commands.registerCommand('aymlAddCommand', (context)=>{cgAdd(context)} );
  context.subscriptions.push(aymlAddCommand)
  let aymlBackCommand = vscode.commands.registerCommand('aymlBackCommand', (context)=>{cgBack(context)} );
  context.subscriptions.push(aymlBackCommand)
}

function deactivate() {
  // console.log('Your extension "ayml" is now deactivated.')
}

module.exports = {
  activate,
  deactivate,
}
